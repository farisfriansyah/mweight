// Frontend: VehicleWeight.js
import React, { useState, useEffect } from 'react';

const VehicleWeight = () => {
  const [weight, setWeight] = useState(null); // Menyimpan berat kendaraan yang diterima

  useEffect(() => {
    const socket = new WebSocket('ws://localhost:3002'); // Koneksi ke WebSocket

    socket.onopen = () => {
      console.log('Terhubung ke WebSocket');
    };

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      setWeight(data.weight); // Update state dengan berat kendaraan yang sudah dalam kilogram
    };

    socket.onclose = () => {
      console.log('WebSocket terputus');
    };

    socket.onerror = (error) => {
      console.error('WebSocket Error:', error);
    };

    return () => {
      socket.close();
    };
  }, []);

  return (
    <div>
      <h1>Berat Kendaraan</h1>
      {weight ? (
        <p>{weight} kg</p>
      ) : (
        <p>Menunggu data berat kendaraan...</p>
      )}
    </div>
  );
};

export default VehicleWeight;
