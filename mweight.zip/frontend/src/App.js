import React from 'react';
import './App.css';
import WeightDisplay from './components/WeightDisplay';

function App() {
  return (
    <div className="App">
      <WeightDisplay />
    </div>
  );
}

export default App;
