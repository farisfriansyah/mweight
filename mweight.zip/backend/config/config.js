module.exports = {
    tcpHost: '10.88.0.44',
    tcpPort: 23,
    wsPort: 3002,
    apiPort: 3001,
};