const tcpService = require('../services/tcpService');

// Endpoint untuk mendapatkan data berat kendaraan
exports.getWeight = (req, res) => {
  const weight = tcpService.getVehicleWeight();
  if (weight) {
    res.json({ weight });
  } else {
    res.status(404).json({ message: 'Data berat kendaraan belum tersedia' });
  }
};
